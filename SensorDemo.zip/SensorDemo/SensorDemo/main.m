//
//  main.m
//  SensorDemo
//
//  Created by Chaosky on 16/1/28.
//  Copyright (c) 2016年 1000phone. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
