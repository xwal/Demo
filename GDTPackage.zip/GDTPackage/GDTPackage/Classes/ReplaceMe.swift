import GDTPackageBridge

public class GDTPackage {
    
    public init() {
        
    }
    
    public func test() {
        GDTSplashAd.init()
    }
}
