//
//  ViewController.swift
//  GDTPackage
//
//  Created by chaoskyme on 10/28/2020.
//  Copyright (c) 2020 chaoskyme. All rights reserved.
//

import UIKit
import GDTPackage

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        GDTPackage().test()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}

