# GDTPackage

[![CI Status](https://img.shields.io/travis/chaoskyme/GDTPackage.svg?style=flat)](https://travis-ci.org/chaoskyme/GDTPackage)
[![Version](https://img.shields.io/cocoapods/v/GDTPackage.svg?style=flat)](https://cocoapods.org/pods/GDTPackage)
[![License](https://img.shields.io/cocoapods/l/GDTPackage.svg?style=flat)](https://cocoapods.org/pods/GDTPackage)
[![Platform](https://img.shields.io/cocoapods/p/GDTPackage.svg?style=flat)](https://cocoapods.org/pods/GDTPackage)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

GDTPackage is available through [CocoaPods](https://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'GDTPackage'
```

## Author

chaoskyme, chaosky.me@gmail.com

## License

GDTPackage is available under the MIT license. See the LICENSE file for more info.
