//
//  ViewController.h
//  ApplePayDemo
//
//  Created by Chaosky on 16/8/8.
//  Copyright © 2016年 1000phone. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

