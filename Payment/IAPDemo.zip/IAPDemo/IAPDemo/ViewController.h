//
//  ViewController.h
//  IAPDemo
//
//  Created by Chaosky on 16/1/24.
//  Copyright (c) 2016年 1000phone. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

