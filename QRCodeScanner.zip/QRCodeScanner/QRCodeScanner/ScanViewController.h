//
//  ScanViewController.h
//  QRCodeScanner
//
//  Created by Chaosky on 15/10/30.
//  Copyright (c) 2015年 1000phone. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ScanViewController : UIViewController

@end
