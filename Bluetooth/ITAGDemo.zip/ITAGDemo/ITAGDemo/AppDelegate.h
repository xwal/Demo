//
//  AppDelegate.h
//  ITAGDemo
//
//  Created by Chaosky on 16/5/26.
//  Copyright © 2016年 1000phone. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

